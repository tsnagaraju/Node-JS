//step - 1: import events module
var events = require('events');
// step - 2: create object for EventEmiter
var eventEmitter = new events.EventEmitter();
// step - 3: registering listener and defining event handler
eventEmitter.on('sum', function(a, b){
    console.log("Sum: " + (a + b));
})
eventEmitter.on('sub', function(a, b){
    console.log('Sub: ' + (a - b))
})
//step - 4: emit events
eventEmitter.emit('sum', 5, 1);
eventEmitter.emit('sub', 9, 5);