var express = require('express');
var mysql = require('mysql');
var bodyParser = require('body-parser');
var app = express();
var urle = bodyParser.urlencoded({extended: true});

var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'nodemysql'
})


app.get('/home.html', function(req, res) {
    res.sendFile(__dirname + '/home.html')
})
app.get('/view_products', function(req, res){
    var sql = "select *from products";
    con.query(sql, function(err, result){
        res.json(result);
        res.end();
    })
})
app.get('/add_product.html', function(req, res){
    res.sendFile(__dirname + '/add_product.html');
})
app.post('/addp', urle, function(req, res){
    var name = req.body.name;
    var price = req.body.price;
    var sql = "insert into products(pname, price) values('"+name+"','"+price+"')";
    con.query(sql, function(err, result){
        if (err) throw err;
        res.write('<b>record inserted</b>')
        console.log('record inserted')
    })
})
app.listen(7000);
console.log('started...')