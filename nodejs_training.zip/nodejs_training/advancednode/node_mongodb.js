var md = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

md.connect(url, function(err, db){
    if (err) throw err;
    console.log('connected database...');
    var dbo = db.db('nodemdb');
    
    dbo.collection('customers').find({}).toArray(function(err, result){
        if (err) throw err;
        console.log(result);
    })
})
