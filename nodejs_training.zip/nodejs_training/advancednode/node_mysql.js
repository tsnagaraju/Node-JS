var mysql = require('mysql');
var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'nodemysql'
})
con.connect(function(err){
    if (err) throw err;
    console.log('connected to database');
})
var sql = "select *from products";
con.query(sql, function(err, result){
    if (err) throw err;
    console.log(result);
})


