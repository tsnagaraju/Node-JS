var http = require("http");
http.createServer(function(req, resp) {
   resp.writeHead(200, {'Content-Type': 'text/plain'});
   resp.end("this is my first web based node app");
}).listen(9292);

console.log("server listening on port: http://localhost:9292");