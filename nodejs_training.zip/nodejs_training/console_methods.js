console.table("this is a console table mehtods")
//console log
console.log("this is a log method")
//console error
console.error("there is an error in line 21");
// console warn
console.warn("don't come in my way");