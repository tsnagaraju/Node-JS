var events = require('events');
var fs = require('fs');
var ee = new events.EventEmitter();
ee.on('write', function(data){
    fs.writeFile('events.txt', data, (err)=>{if (err){console.log(err)}} )
    console.log("data written to a file...")
})
ee.emit('write', "hai, today we are discussing on node modules: event module");
ee.on('read', function(){
    fs.readFile('events.txt', function(err, data){
        console.log(data.toString());
    })
})
setTimeout(function() {
    ee.emit('read');
}, 5000);
