var fs = require("fs");
fs.readFile("test.txt", function(err, data){
    if (err){
        console.log(err)
    }
    setTimeout(()=>{
        console.log("asynchronous call")
    }, 2000)
})
console.log("start here")