var http = require('http');
var fs = require('fs');
http.createServer(function(req, res){
    fs.readFile('events.txt', function(err, data){
        res.writeHead(200, {'Content-Type':'text/html'});
        res.write("<b>" + data.toString() + "</b>");
        res.end();
    })
}).listen(3000);
console.log("server listening to http://localhost:3000")