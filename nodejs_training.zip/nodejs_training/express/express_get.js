var express = require('express');
var app = express();
app.get('/login.html', function(req, res){
    res.sendFile(__dirname + '/login.html');
})
app.get('/process_get', function(req, res){
    res.write(req.query.username + " " + req.query.mail + " "+ req.query.phone)
    res.end();
})
app.get('/process_get/:message', function(req, res){
    //res.write(req.query.username + " " + req.query.mail + " "+ req.query.phone)
    res.write("<b>" + req.params.message + "</b>")
    res.end();
})
app.listen(4000);
console.log("start")