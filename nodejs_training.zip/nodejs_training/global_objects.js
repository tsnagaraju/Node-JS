console.log(__dirname)
console.log(__filename)

function display() {
    console.log("time displaying with in a moment...")
}
function show() {
    console.log("this is demo for set immediate...");
}

setTimeout(display, 2000);
setImmediate(show)
setInterval(display, 2000);